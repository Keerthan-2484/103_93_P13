# Traffic Signal Fault Dispatcher (Parts C and D)
Stack: React (Vite) frontend, Flask backend, SQLite DB (item 10 of the brief).
Run backend:  cd backend && pip install -r requirements.txt && python app.py      (port 5000)
Run frontend: cd frontend && npm install && npm run dev                          (proxies /api to :5000)
Tests (17 cases, Part D): cd backend && pytest -v
Deploy: `npm run build` in frontend, host dist/ (Netlify/Vercel); host backend on Render/PythonAnywhere and point the /api proxy there.
