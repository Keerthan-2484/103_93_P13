"""Traffic Signal Fault Dispatcher - Flask + SQLite backend (Parts A+B logic wired into one workflow).
Swap dfa_accepts/classify/DIST with your own Part A/B modules if you prefer; the API stays the same."""
import os, re, sqlite3, uuid, threading
from datetime import datetime
from flask import Flask, jsonify, request

DB = os.environ.get("DB_PATH", "dispatcher.db")
LOCK = threading.Lock()
app = Flask(__name__)

# ---------- Part A: DFA + regex ----------
def _cls(c): return "U" if c.isascii() and c.isalpha() and c.isupper() else "D" if c in "0123456789" else c
JUNCTION_DFA = {"start": "q0", "accept": {"q5"}, "t": {("q0","J"):"q1", ("q1","U"):"q2", ("q2","D"):"q3", ("q3","D"):"q4", ("q4","D"):"q5"}}
FAULT_DFA = {"start": "q0", "accept": {"q3"}, "t": {("q0","F"):"q1", ("q1","D"):"q2", ("q2","D"):"q3"}}
JUNCTION_RE = re.compile(r"J[A-Z][0-9]{3}"); FAULT_RE = re.compile(r"F[0-9]{2}")

def dfa_accepts(dfa, s):
    st = dfa["start"]
    for ch in s:
        st = dfa["t"].get((st, ch)) or dfa["t"].get((st, _cls(ch)))
        if st is None: return False          # dead state
    return st in dfa["accept"]

def validate(junction, fault):
    errs = []
    for name, val, dfa, rx, hint in (("Junction ID", junction, JUNCTION_DFA, JUNCTION_RE, "J + zone letter + 3 digits, e.g. JN101"),
                                     ("Fault code", fault, FAULT_DFA, FAULT_RE, "F + 2 digits, e.g. F12")):
        if not val: errs.append(f"{name} is required ({hint})"); continue
        d, r = dfa_accepts(dfa, val), bool(rx.fullmatch(val))
        assert d == r, "DFA/regex disagreement"
        if not d: errs.append(f"{name} '{val}' is malformed: expected {hint}")
    return {"errors": errs, "valid": not errs}

CODE_RANGES = [(10, 19, "Arterial-Blocked"), (20, 29, "Signal-Dark"), (30, 39, "Partial-Fault"), (40, 49, "Flashing-Mode"), (50, 59, "Minor")]
KEYWORDS = {"Arterial-Blocked": r"block|accident|collision|obstruct", "Signal-Dark": r"dark|no power|blackout|dead",
            "Partial-Fault": r"partial|stuck|one lane|red only|green only", "Flashing-Mode": r"flash|blink",
            "Minor": r"minor|cosmetic|dim|sticker|paint"}
RANK = ["Arterial-Blocked", "Signal-Dark", "Partial-Fault", "Flashing-Mode", "Minor"]   # conflict rule: earliest wins
PRIORITY = {"Arterial-Blocked": 1, "Signal-Dark": 1, "Partial-Fault": 2, "Flashing-Mode": 3, "Minor": 4}

def classify(code, desc):
    n, hits = int(code[1:]), set()
    hits |= {c for lo, hi, c in CODE_RANGES if lo <= n <= hi}
    hits |= {c for c, p in KEYWORDS.items() if re.search(p, (desc or "").lower())}
    return min(hits, key=RANK.index) if hits else None          # None = unmapped, never silently assigned

# ---------- Part B: routing table ----------
DEPOTS = {"D1": "North Depot", "D2": "South Depot", "D3": "East Depot", "D4": "West Depot"}
DIST = {"N": {"D1": 2, "D2": 14, "D3": 9, "D4": 8}, "S": {"D1": 14, "D2": 2, "D3": 8, "D4": 9},
        "E": {"D1": 9, "D2": 8, "D3": 2, "D4": 13}, "W": {"D1": 8, "D2": 9, "D3": 13, "D4": 2}}
CENTRAL = "CENTRAL"
ORDER = ["Pending", "Assigned", "In Progress", "Resolved"]

def conn():
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row; return c

def init_db(reset=False):
    c = conn()
    if reset: c.executescript("drop table if exists reports; drop table if exists depots;")
    c.executescript("""create table if not exists depots(id text primary key, name text, capacity int, available int, load int);
    create table if not exists reports(seq integer primary key autoincrement, id text unique, reporter text, junction text, fault text,
      description text, urgency text, zone text, category text, priority int, valid int, validation text, status text,
      handler text, decision text, created_at text, updated_at text);""")
    if not c.execute("select count(*) from depots").fetchone()[0]:
        c.executemany("insert into depots values(?,?,?,?,?)", [(d, n, 2, 1, 0) for d, n in DEPOTS.items()])
    c.commit(); c.close()

def now(): return datetime.utcnow().isoformat(timespec="seconds")

def assign(c, r, handler, decision, status="Assigned"):
    c.execute("update reports set handler=?, status=?, decision=?, updated_at=? where id=?", (handler, status, decision, now(), r["id"]))
    if handler in DEPOTS: c.execute("update depots set load=load+1 where id=?", (handler,))

def dispatch(c, r):
    """Dispatch algorithm: routing key (zone) from a validated report -> table lookup -> availability/capacity check."""
    note = r["decision"] if r["decision"] and r["decision"].startswith("Priority override") else ""
    if r["zone"] not in DIST:
        return assign(c, r, CENTRAL, note + f"Unknown zone '{r['zone']}': sent to central fallback queue for correction", "Pending")
    for i, d in enumerate(sorted(DIST[r["zone"]], key=DIST[r["zone"]].get)):
        dep = c.execute("select * from depots where id=?", (d,)).fetchone()
        if dep["available"] and dep["load"] < dep["capacity"]:
            return assign(c, r, d, note + f"{'Primary' if i == 0 else 'Backup'} depot {d} ({DIST[r['zone']][d]} km)")
    if r["priority"] == 1:
        return assign(c, r, CENTRAL, note + "Escalated to central control: all depots unavailable or at capacity (P1)")
    c.execute("update reports set decision=? where id=?", (note + "Queued: all depots busy", r["id"]))

def drain(c):  # deterministic queue order: priority, then arrival sequence
    for r in c.execute("select * from reports where valid=1 and handler is null order by priority, seq").fetchall():
        dispatch(c, r)

@app.after_request
def cors(resp):
    resp.headers["Access-Control-Allow-Origin"] = "*"; resp.headers["Access-Control-Allow-Headers"] = "Content-Type"
    resp.headers["Access-Control-Allow-Methods"] = "GET,POST,PATCH,OPTIONS"; return resp

def preview(b):
    j, f, d = (str(b.get(k, "")).strip() for k in ("junction", "fault", "description"))
    v = validate(j, f); cat = classify(f, d) if v["valid"] else None
    pr = PRIORITY.get(cat, 4)
    if b.get("urgency") == "emergency": pr = 1
    return {**v, "category": cat or ("Unclassified" if v["valid"] else None), "priority": pr if v["valid"] else None}

@app.post("/api/validate")
def api_validate(): return jsonify(preview(request.get_json(silent=True) or {}))

@app.post("/api/reports")
def submit():
    b = request.get_json(silent=True) or {}
    p = preview(b); errs = list(p["errors"]); reporter = str(b.get("reporter", "")).strip()
    urg = b.get("urgency", "normal")
    if not reporter: errs.append("Reporter name is required")
    if urg not in ("normal", "high", "emergency"): errs.append("Urgency must be normal, high or emergency")
    j, f = str(b.get("junction", "")).strip(), str(b.get("fault", "")).strip()
    rid, ts = "TSF-" + uuid.uuid4().hex[:6].upper(), now()
    with LOCK:
        c = conn()
        if errs:
            c.execute("insert into reports(id,reporter,junction,fault,description,urgency,valid,validation,status,decision,created_at,updated_at) values(?,?,?,?,?,?,0,?,?,?,?,?)",
                      (rid, reporter, j, f, b.get("description", ""), urg, "; ".join(errs), "Rejected", "Rejected before dispatch", ts, ts))
            c.commit(); return jsonify({"id": rid, "errors": errs}), 422
        note = "Priority override (emergency). " if urg == "emergency" and PRIORITY.get(p["category"], 4) > 1 else ""
        c.execute("insert into reports(id,reporter,junction,fault,description,urgency,zone,category,priority,valid,validation,status,decision,created_at,updated_at) values(?,?,?,?,?,?,?,?,?,1,'valid','Pending',?,?,?)",
                  (rid, reporter, j, f, b.get("description", ""), urg, j[1], p["category"], p["priority"], note, ts, ts))
        dispatch(c, c.execute("select * from reports where id=?", (rid,)).fetchone())
        c.commit(); row = dict(c.execute("select * from reports where id=?", (rid,)).fetchone()); c.close()
    return jsonify(row), 201

@app.get("/api/reports")
def list_reports():
    c = conn(); h = request.args.get("handler")
    rows = c.execute("select * from reports where valid=1" + (" and handler=?" if h else "") + " order by priority, seq", (h,) if h else ()).fetchall()
    return jsonify([dict(r) for r in rows])

@app.get("/api/reports/<rid>")
def get_report(rid):
    r = conn().execute("select * from reports where id=?", (rid.upper(),)).fetchone()
    return (jsonify(dict(r)), 200) if r else (jsonify({"error": "Report not found"}), 404)

@app.post("/api/reports/<rid>/status")
def set_status(rid):
    s = (request.get_json(silent=True) or {}).get("status")
    with LOCK:
        c = conn(); r = c.execute("select * from reports where id=?", (rid,)).fetchone()
        if not r: return jsonify({"error": "Report not found"}), 404
        if not r["valid"] or s not in ORDER or ORDER.index(s) <= ORDER.index(r["status"]) or not r["handler"]:
            return jsonify({"error": f"Cannot move {r['status']} -> {s}"}), 400
        c.execute("update reports set status=?, updated_at=? where id=?", (s, now(), rid))
        if s == "Resolved" and r["handler"] in DEPOTS:
            c.execute("update depots set load=max(load-1,0) where id=?", (r["handler"],)); drain(c)
        c.commit(); return jsonify(dict(c.execute("select * from reports where id=?", (rid,)).fetchone()))

@app.get("/api/depots")
def depots(): return jsonify([dict(r) for r in conn().execute("select * from depots")])

@app.patch("/api/depots/<did>")
def patch_depot(did):
    b = request.get_json(silent=True) or {}
    with LOCK:
        c = conn()
        if did not in DEPOTS: return jsonify({"error": "Unknown depot"}), 404
        if "capacity" in b:
            if not isinstance(b["capacity"], int) or b["capacity"] < 0: return jsonify({"error": "Capacity must be a non-negative integer"}), 400
            c.execute("update depots set capacity=? where id=?", (b["capacity"], did))
        if "available" in b: c.execute("update depots set available=? where id=?", (int(bool(b["available"])), did))
        drain(c); c.commit()
    return jsonify([dict(r) for r in conn().execute("select * from depots")])

@app.get("/api/routing")
def routing():
    c = conn(); rows = [dict(r) for r in c.execute("select * from reports where valid=1 order by priority, seq")]
    return jsonify({"matrix": DIST, "depots": [dict(r) for r in c.execute("select * from depots")],
                    "queue": [r for r in rows if r["handler"] is None],
                    "decisions": [r for r in rows if r["handler"] and ("Escalated" in r["decision"] or "override" in r["decision"] or "Backup" in r["decision"] or "fallback" in r["decision"])]})

@app.get("/api/stats")
def stats():
    c = conn(); valid = [dict(r) for r in c.execute("select * from reports where valid=1")]
    count = lambda k: {v: sum(1 for r in valid if r[k] == v) for v in sorted({r[k] for r in valid if r[k]})}
    st = count("status")
    return jsonify({"total": len(valid), "rejected": c.execute("select count(*) from reports where valid=0").fetchone()[0], "by_status": st,
                    "by_zone": count("zone"), "by_category": count("category"), "resolved": st.get("Resolved", 0), "unresolved": len(valid) - st.get("Resolved", 0)})

init_db()
if __name__ == "__main__": app.run(port=5000, debug=True)
