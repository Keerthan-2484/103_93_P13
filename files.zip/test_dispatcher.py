"""Part D - 17 documented test cases. Run: pytest -v"""
import os, tempfile, threading
os.environ["DB_PATH"] = os.path.join(tempfile.mkdtemp(), "t.db")
import pytest, app as A

@pytest.fixture(autouse=True)
def fresh(): A.init_db(reset=True); yield
cl = A.app.test_client()
def sub(j="JN101", f="F25", d="", u="normal", who="Officer A"):
    r = cl.post("/api/reports", json={"reporter": who, "junction": j, "fault": f, "description": d, "urgency": u}); return r.status_code, r.get_json()

def test_01_valid_formats_dfa_and_regex_accept():
    for j, f in [("JN101", "F12"), ("JS999", "F00"), ("JW000", "F59")]:
        assert A.dfa_accepts(A.JUNCTION_DFA, j) and A.JUNCTION_RE.fullmatch(j) and A.dfa_accepts(A.FAULT_DFA, f) and A.FAULT_RE.fullmatch(f)
def test_02_invalid_formats_dfa_and_regex_agree():
    for j in ["", "J101", "JN10", "JN1011", "jn101", "XN101", "JNA01", "JN101 "]:
        assert A.dfa_accepts(A.JUNCTION_DFA, j) == bool(A.JUNCTION_RE.fullmatch(j)) == False
    for f in ["", "F1", "F123", "f12", "G12", "FA2"]:
        assert A.dfa_accepts(A.FAULT_DFA, f) == bool(A.FAULT_RE.fullmatch(f)) == False
@pytest.mark.parametrize("code,cat", [("F15", "Arterial-Blocked"), ("F25", "Signal-Dark"), ("F35", "Partial-Fault"), ("F45", "Flashing-Mode"), ("F55", "Minor")])
def test_03_to_07_all_five_categories(code, cat):
    s, r = sub(f=code); assert s == 201 and r["category"] == cat
def test_08_conflicting_patterns_use_priority_rule():
    s, r = sub(f="F55", d="minor paint issue but road is blocked after accident"); assert r["category"] == "Arterial-Blocked"
def test_09_unmapped_code_not_silently_categorised():
    s, r = sub(f="F99"); assert r["category"] == "Unclassified" and r["priority"] == 4 and r["handler"] in A.DIST["N"]
def test_10_unknown_zone_goes_to_central_fallback():
    s, r = sub(j="JZ123"); assert r["handler"] == "CENTRAL" and "fallback" in r["decision"] and r["status"] == "Pending"
def test_11_malformed_identifier_rejected_before_dispatch():
    s, r = sub(j="JN12"); assert s == 422 and "malformed" in r["errors"][0]
    assert cl.get("/api/reports").get_json() == [] and cl.get("/api/stats").get_json()["rejected"] == 1
def test_12_nearest_depot_is_primary():
    s, r = sub(j="JS200"); assert r["handler"] == "D2" and r["decision"].startswith("Primary")
def test_13_capacity_overflow_uses_backup():
    sub(); sub(); s, r = sub(); assert r["handler"] == "D4" and "Backup" in r["decision"]
def test_14_unavailable_handler_uses_backup():
    cl.patch("/api/depots/D1", json={"available": False}); s, r = sub(); assert r["handler"] == "D4"
def test_15_all_busy_escalates_p1_and_queues_others():
    for d in A.DEPOTS: cl.patch(f"/api/depots/{d}", json={"capacity": 0})
    _, p1 = sub(f="F11"); _, p4 = sub(f="F55")
    assert p1["handler"] == "CENTRAL" and "Escalated" in p1["decision"] and p4["handler"] is None and p4["decision"].startswith("Queued")
def test_16_emergency_priority_override():
    s, r = sub(f="F55", u="emergency"); assert r["priority"] == 1 and "Priority override" in r["decision"]
def test_17_queue_order_and_status_lifecycle_persist():
    for d in A.DEPOTS: cl.patch(f"/api/depots/{d}", json={"capacity": 0})
    _, minor = sub(f="F55"); _, partial = sub(f="F35")
    cl.patch("/api/depots/D1", json={"capacity": 1})                      # one slot frees up: higher priority wins
    assert cl.get(f"/api/reports/{partial['id']}").get_json()["handler"] == "D1" and cl.get(f"/api/reports/{minor['id']}").get_json()["handler"] is None
    for s in ("In Progress", "Resolved"): assert cl.post(f"/api/reports/{partial['id']}/status", json={"status": s}).status_code == 200
    assert cl.post(f"/api/reports/{partial['id']}/status", json={"status": "Assigned"}).status_code == 400   # no backwards moves
    assert cl.get(f"/api/reports/{minor['id']}").get_json()["handler"] == "D1"                                # queue drained on resolve
def test_18_simultaneous_reports_no_over_assignment():
    ts = [threading.Thread(target=sub) for _ in range(12)]; [t.start() for t in ts]; [t.join() for t in ts]
    assert all(d["load"] <= d["capacity"] for d in cl.get("/api/depots").get_json())
