import {useState, useEffect, useCallback} from "react";
const api = async (p, method, body) => { const r = await fetch("/api" + p, body !== undefined || method ? {method: method || "GET", headers: {"Content-Type": "application/json"}, body: JSON.stringify(body)} : undefined); return {ok: r.ok, data: await r.json()}; };
const Pri = ({p}) => p ? <span className={`tag P${p}`}>P{p}</span> : null;
function useLoad(path, dep) { const [d, setD] = useState(null); const load = useCallback(() => api(path).then(r => setD(r.data)), [path]); useEffect(() => { load(); const t = setInterval(load, 5000); return () => clearInterval(t); }, [load, dep]); return [d, load]; }

function Submit() {
  const empty = {reporter: "", junction: "", fault: "", description: "", urgency: "normal"};
  const [f, setF] = useState(empty), [pv, setPv] = useState(null), [res, setRes] = useState(null);
  const set = k => e => { const n = {...f, [k]: k === "junction" || k === "fault" ? e.target.value.toUpperCase() : e.target.value}; setF(n); api("/validate", "POST", n).then(r => setPv(r.data)); };
  const send = async e => { e.preventDefault(); const r = await api("/reports", "POST", f); setRes(r); if (r.ok) { setF(empty); setPv(null); } };
  return <div className="grid"><form className="panel" onSubmit={send}><h2>Report a signal fault</h2>
    <label htmlFor="r">Your name</label><input id="r" value={f.reporter} onChange={set("reporter")}/>
    <label htmlFor="j">Junction ID (e.g. JN101)</label><input id="j" value={f.junction} onChange={set("junction")}/>
    <label htmlFor="c">Fault code (e.g. F25)</label><input id="c" value={f.fault} onChange={set("fault")}/>
    <label htmlFor="d">What is happening?</label><textarea id="d" rows="3" value={f.description} onChange={set("description")}/>
    <label htmlFor="u">Urgency</label><select id="u" value={f.urgency} onChange={set("urgency")}><option>normal</option><option>high</option><option>emergency</option></select>
    {pv && (f.junction || f.fault) && <div aria-live="polite">{pv.errors.map(x => <p className="err" key={x}>{x}</p>)}
      {pv.valid && <p className="ok">Detected: <b>{pv.category}</b> <Pri p={pv.priority}/></p>}</div>}
    <button className="act">Send report</button></form>
    <div className="panel"><h2>Result</h2>{!res && <p>Submit a report to see its ID and assigned handler.</p>}
      {res?.ok && <><p className="ok">Report <b>{res.data.id}</b> accepted.</p><p>{res.data.category} <Pri p={res.data.priority}/></p><p>{res.data.decision}</p><p>Status: {res.data.status}</p></>}
      {res && !res.ok && <><p className="err">Report {res.data.id} was rejected before dispatch:</p>{res.data.errors.map(x => <p className="err" key={x}>{x}</p>)}</>}</div></div>;
}

function User() {
  const [s] = useLoad("/stats"), [id, setId] = useState(""), [found, setFound] = useState(null);
  const q = e => { e.preventDefault(); api("/reports/" + id.trim()).then(setFound); };
  const st = s?.by_status || {};
  return <><div className="grid">{[["Total", s?.total], ["Pending", st.Pending || 0], ["Assigned", (st.Assigned || 0) + (st["In Progress"] || 0)], ["Resolved", st.Resolved || 0]].map(([k, v]) =>
    <div className="panel stat" key={k}><b>{v ?? "-"}</b><span>{k}</span></div>)}</div>
    <form className="panel" onSubmit={q}><h2>Track a report</h2><label htmlFor="t">Report ID</label><input id="t" placeholder="TSF-1A2B3C" value={id} onChange={e => setId(e.target.value)}/><button className="act">Find report</button>
      {found && (found.ok ? <p>Status: <b>{found.data.status}</b> | Handler: <b>{found.data.handler || "Waiting in queue"}</b> | {found.data.category} <Pri p={found.data.priority}/></p> : <p className="err">{found.data.error}</p>)}</form></>;
}

function Handler() {
  const [dep, setDep] = useState("D1"), [tick, setTick] = useState(0), [rows] = useLoad("/reports?handler=" + dep, tick), [ds] = useLoad("/depots", tick);
  const d = ds?.find(x => x.id === dep), bump = () => setTick(t => t + 1);
  const move = async (id, status) => { await api(`/reports/${id}/status`, "POST", {status}); bump(); };
  const patch = async b => { await api("/depots/" + dep, "PATCH", b); bump(); };
  const next = {Assigned: "In Progress", "In Progress": "Resolved"};
  return <div className="panel"><h2>Handler dashboard</h2><label htmlFor="h">Depot</label>
    <select id="h" value={dep} onChange={e => setDep(e.target.value)}>{["D1", "D2", "D3", "D4", "CENTRAL"].map(x => <option key={x}>{x}</option>)}</select>
    {d && <p>Load {d.load}/{d.capacity} <label style={{display: "inline"}}> <input type="checkbox" style={{width: "auto"}} checked={!!d.available} onChange={e => patch({available: e.target.checked})}/> Available</label>{" "}
      <button className="sm" onClick={() => patch({capacity: d.capacity + 1})}>Capacity +1</button><button className="sm" onClick={() => patch({capacity: Math.max(0, d.capacity - 1)})}>Capacity -1</button></p>}
    <div className="scroll"><table><thead><tr><th>ID</th><th>Category</th><th>Zone</th><th>Priority</th><th>Submitted</th><th>Status</th><th>Action</th></tr></thead><tbody>
      {rows?.map(r => <tr key={r.id}><td>{r.id}</td><td>{r.category}</td><td>{r.zone}</td><td><Pri p={r.priority}/></td><td>{r.created_at}</td><td>{r.status}</td><td>{next[r.status] ? <button className="sm" onClick={() => move(r.id, next[r.status])}>Mark {next[r.status]}</button> : r.status === "Pending" ? <button className="sm" onClick={() => move(r.id, "Assigned")}>Mark Assigned</button> : "Done"}</td></tr>)}
      {rows?.length === 0 && <tr><td colSpan="7">No reports assigned to {dep}.</td></tr>}</tbody></table></div></div>;
}

function Routing() {
  const [r] = useLoad("/routing"); if (!r) return null;
  const T = ({rows}) => <div className="scroll"><table><tbody>{rows}</tbody></table></div>;
  return <><div className="panel"><h2>Routing table (distance in km)</h2><T rows={<><tr><th>Zone</th>{r.depots.map(d => <th key={d.id}>{d.id}</th>)}</tr>{Object.entries(r.matrix).map(([z, m]) => <tr key={z}><td><b>{z}</b></td>{r.depots.map(d => <td key={d.id}>{m[d.id]}</td>)}</tr>)}</>}/></div>
    <div className="panel"><h2>Handler loads</h2><T rows={<><tr><th>Depot</th><th>Load</th><th>Capacity</th><th>Available</th></tr>{r.depots.map(d => <tr key={d.id}><td>{d.name}</td><td>{d.load}</td><td>{d.capacity}</td><td>{d.available ? "Yes" : "No"}</td></tr>)}</>}/></div>
    <div className="panel"><h2>Queued reports ({r.queue.length})</h2><T rows={r.queue.map(q => <tr key={q.id}><td>{q.id}</td><td>{q.category}</td><td><Pri p={q.priority}/></td><td>{q.decision}</td></tr>)}/></div>
    <div className="panel"><h2>Escalation, backup and override decisions</h2><T rows={r.decisions.map(q => <tr key={q.id}><td>{q.id}</td><td>{q.handler}</td><td>{q.decision}</td></tr>)}/></div></>;
}

function Analytics() {
  const [s] = useLoad("/stats"); if (!s) return null;
  const Chart = ({title, data}) => { const m = Math.max(1, ...Object.values(data)); return <div className="panel"><h2>{title}</h2>{Object.entries(data).map(([k, v]) => <div className="bar" key={k}><span style={{width: 120}}>{k}</span><i style={{width: `${(v / m) * 60}%`}}/><b>{v}</b></div>)}{!Object.keys(data).length && <p>No data yet.</p>}</div>; };
  return <><div className="grid"><div className="panel stat"><b>{s.resolved}</b><span>Resolved</span></div><div className="panel stat"><b>{s.unresolved}</b><span>Unresolved</span></div><div className="panel stat"><b>{s.rejected}</b><span>Rejected on entry</span></div></div>
    <div className="grid"><Chart title="Reports by zone" data={s.by_zone}/><Chart title="Reports by category" data={s.by_category}/><Chart title="Reports by status" data={s.by_status}/></div></>;
}

const TABS = {"Report a fault": Submit, "My reports": User, "Handler": Handler, "Routing": Routing, "Analytics": Analytics};
export default function App() {
  const [t, setT] = useState("Report a fault"); const C = TABS[t];
  return <><header><h1>Traffic Signal Fault Dispatcher</h1><nav>{Object.keys(TABS).map(k => <button key={k} className={k === t ? "on" : ""} onClick={() => setT(k)}>{k}</button>)}</nav></header><main><C/></main></>;
}
